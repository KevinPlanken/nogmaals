i = 30
while i > 0:
    print(i)
    i -= 1
print('de raket gaat nu opstijgen')    