i = 24
while i > 0:
    if i <= 11:
        print(str(i) + ":00 " + "AM")
    else:
        print(str(i) + ":00 " + "PM")   
    i -= 1
    
