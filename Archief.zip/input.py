while True:
    quit = input(" ")
    if quit == "quit":
        break