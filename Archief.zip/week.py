dagen = 0
week = ['Maandag', 'Dinsdag', 'Woensdag', 'Donderdag', 'Vrijdag', 'Zaterdag', 'Zondag']
while dagen < 5:
   print(week[dagen])
   dagen += 1