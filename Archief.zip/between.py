i = 50
while i > 20:
    print(i)
    i -= 1